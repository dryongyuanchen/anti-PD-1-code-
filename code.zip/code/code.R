# Figure 1 c
# Figure 2 b
# Figure 3 b
# Figure 4 e

library(reshape2)
library(ggplot2)
library(tidyr)
library(tibble)
library(dplyr)
library(ggpubr)
x = read.csv("******.csv", header = TRUE, row.names = NULL,check.names=F)  
# Figure 1 c/Figure 2 b (left)/Figure 2 b (right)/Figure 3 b (left)/Figure 3 b (right)/Figure 4 e (left)/Figure 4 e (right)
res_per = x%>%
  as.data.frame()%>%
  rownames_to_column()%>%
  mutate(group= c("anti-PD-1","anti-PD-1","anti-PD-1","anti-PD-1","anti-PD-1"
                  ,"anti-PD-1","anti-PD-1","anti-PD-1","anti-PD-1","anti-PD-1"
                  ,"anti-PD-1","anti-PD-1","anti-PD-1","anti-PD-1","anti-PD-1"
                  ,"anti-PD-1","anti-PD-1","anti-PD-1","anti-PD-1","anti-PD-1"
                  ,"anti-PD-1","anti-PD-1","anti-PD-1",
                  "T","T","T","T","T","T","N","N","N","N","N","N"))
mydata <- melt(res_per)  
mydata$group=factor(mydata$group, levels=c("anti-PD-1","T","N")) 
ggboxplot(mydata, x = "variable", y = "value", width = 0.8,
          color = "group",add = "jitter", palette = "jama",
          xlab ="",ylab ="")+
  theme(
    axis.text.x = element_blank(),axis.text.y = element_blank(),
    legend.position = 'none'#"right"
  )+
  scale_color_manual(values=c("red", "blue", "green"))

# Figure 1 d
library(tidyverse)
library(reshape2)
library(Hmisc)
library(corrplot)
library(RColorBrewer)
attitude = read.csv("******.csv",  # Figure 1 d
                    row.names = 1,check.names = FALSE)
cor_ <- cor(attitude, method = 'pearson')
cortest <- rcorr(as.matrix(attitude), type = "pearson")
cormat <-cor_
melted_cormat <- melt(cormat)
melted_pmt <- melt(pmt)
colnames(melted_pmt)[3]= "Pvalue" 
melted_cormat$Pvalue=melted_pmt[3]
col2 <- colorRampPalette(c("red","yellow" ,"blue"),alpha = TRUE)(100)
corrplot(-cor_,order="original",tl.pos = "n",method = "square",
         addgrid.col = "grey90",col = col2,outline="black",
         cl.length=5,cl.ratio = 0.2,tl.srt= 0,
         p.mat = cortest$P, sig.level = c(.0001,.001, .01, .05),
         insig = "label_sig",pch.cex = 0.8, pch.col = "white")

# Figure 1 e
library(ggplot2)
library(limma)
library(pheatmap)
library(ggsci)
library(dplyr)
rt=read.table("******.txt",sep="\t",header=T,check.names=F) # Figure 1 e
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp),colnames(exp))
rt=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
rt=avereps(rt)
data<-na.omit(rt)
head(data)
rt=data
max(rt)
head(rt)
if(max(rt)>30) rt=log2(rt+1)
rt=normalizeBetweenArrays(as.matrix(rt))
data=rt
head(data)
afcon=9
conData=data[,as.vector(colnames(data)[1:afcon])]
aftreat=afcon+1
treatData=data[,as.vector(colnames(data)[aftreat:ncol(data)])]
rt=cbind(conData,treatData)
conNum=ncol(conData)
treatNum=ncol(treatData)
Type=c(rep("con",conNum),rep("treat",treatNum))
design <- model.matrix(~0+factor(Type))
colnames(design) <- c("con","treat")
fit <- lmFit(rt,design)
cont.matrix<-makeContrasts(treat-con,levels=design)
fit2 <- contrasts.fit(fit, cont.matrix)
fit2 <- eBayes(fit2)
Diff=topTable(fit2,adjust='fdr',number=length(rownames(data)))
DIFFOUT=rbind(id=colnames(Diff),Diff)
write.table(DIFFOUT,file="DIFF_all.xls",sep="\t",quote=F,col.names=F)
diffSig=Diff[with(Diff, (abs(logFC)>1 & P.Value < 0.05 )), ]
diffSigOut=rbind(id=colnames(diffSig),diffSig)
write.table(diffSigOut,file="DIFF_af.xls",sep="\t",quote=F,col.names=F)
Type=c(rep("N",conNum),rep("T",treatNum))
names(Type)=colnames(rt)
Type=as.data.frame(Type)
anncolor=list(Type=c(T=pal_npg()(1),N=pal_npg()(2)[2]))
afGene=c(
  'CD8A','CD8B','EOMES','TNFSF9','GNLY','IFNG','GZMM','GZMH','GZMA','GZMB',
  'KLRC4','KLRC3','KLRC2','KLRC1',
  'LAG3', 'HAVCR2',
  'PDCD1', 'CTLA4',
  'CXCR6','ZNF683','SIRPG',
  'CD1C','CD1E','FCER1A'
)
afExp=rt[afGene,]
pheatmap(afExp,                                                                                                                      
         color = colorRampPalette(c(pal_npg()(2)[2],"white", pal_npg()(1)))(50),    
         cluster_cols =F,cluster_rows =F,                                                      
         show_colnames = F,                                                        
         scale="row", 
         fontsize = 10,
         fontsize_row=6,
         fontsize_col=8,
         annotation_colors=anncolor
)

# Figure 1 f
# Figure 1 g
# Figure 3 g
# Figure 3 h
#Extended Data Figure 4 a
#Extended Data Figure 4 c
#Extended Data Figure 4 f
#Extended Data Figure 5 e
#Extended Data Figure 6 h
#Extended Data Figure 6 k
#Extended Data Figure 8 a
#Extended Data Figure 8 d
#Extended Data Figure 10 a
#Extended Data Figure 10 d
library(Seurat)
load('TRM-celltype.Rdata')
DimPlot(sce, reduction = "umap", group.by = "celltype",label =F,  #orig.ident clonetype
        cols=c("#5C8FAE",'#B26054',"#D9AD7F") ,
        split.by = 'path', ncol=1,pt.size=0.5
)

# Figure 1 l
a=read.table("Figure 3 l.txt",check.names = FALSE,
             header = T)
a_order=c(
  'CD69','ITGAE',
  'IL7R', 'KLF2','GPR183','S1PR1','MYADM','TCF7','CCR7','LEF1','SELL','CX3CR1','CXCR3','CXCR5',
  'MKI67','STMN1','TUBB','TUBA1B','TYMS','TOP2A',
  'ZNF683','RBPJ','CXCR6','SIRPG',
  'TBX21',"ID2",'ID3','TOX',"RUNX3","NOTCH3",
  'CD27','CD28',"JAML",'ICOS',
  'IFNG','GZMM','GZMK','GZMH','GZMB','GZMA','PRF1',
  'KLRC1' ,'KLRD1','KLRG1',"GNLY",'NKG7','TNFRSF9','CD38','ENTPD1','HLA-DRA',
  'PDCD1','CTLA4','HAVCR2','TIGIT','LAYN','LAG3')
c=a[which(a[,1] %in% a_order),]
c=c[match(a_order,c[,1]),]
head(c)
row.names(c)<-make.names(c[,1],TRUE)
c<-c[,-1]
c[1:6,1:6]
c2 <- as.data.frame(c) 
c3 <- decostand(c2,"standardize",MARGIN = 1,na.rm=T)
bk <- c(seq(-1,-0.1,by=0.01),seq(0,1,by=0.01))
col = c(colorRampPalette(colors = c("purple", "black"))(length(bk)/2),
        colorRampPalette(colors = c( "black", "gold"))(length(bk)/2))
pheatmap(c3,show_rownames = T,show_colnames = F,
         cluster_cols = F,cluster_rows = F,scale="row",
         color = col,legend_breaks = seq(-1,1,1),breaks=bk,
         cellwidth = 10, cellheight = 10 
) 

# Figure 2 d
#Figure 3 d
#Figure 4 g
#Extended Data Figure 6 d
library(reshape2)
library(ggplot2)
library(tidyr)
library(tibble)
library(dplyr)
library(ggpubr)
x = read.csv("******.csv",  # Figure 2 d (left)/Figure 2 d (right)/Figure 3 d/Figure 4 g (left)/Figure 4 g (right)
             header = TRUE, row.names = NULL,check.names=F)
res_per = x%>%
  as.data.frame()%>%
  rownames_to_column()%>%
  mutate(group= c("MPR","MPR","MPR","MPR","NPR","NPR","NPR","NPR","NPR","NPR","NPR"
                  ,"NPR","NPR","NPR","NPR","NPR","NPR","NPR","NPR","NPR","NPR"
                  ,"NPR","NPR"))
mydata <- melt(res_per)  
ggboxplot(mydata, x = "variable", y = "value", width = 0.8,
          color = "group",
          add = "jitter", palette = "jama",
          xlab ="",ylab ="")+
  theme(
    axis.text.x = element_blank(),axis.text.y = element_blank(),
    legend.position = 'none'
  )+
  scale_color_manual(values=c("orange","#999999" ))

# Figure 2 i
# Figure 5 a
#Extended Data Figure 5 c
#Extended Data Figure 6 b
library(pheatmap)
library(RColorBrewer)
attitude = read.csv("******.csv",  # Figure 2 i/Figure 5 a
                    row.names = 1,check.names = FALSE)
pheatmap(-attitude, clustering_method="average", 
         cluster_cols=F, cluster_rows=F,cellwidth=15,cellheight = 15,
         fontsize_number = 12, number_color = "white",
         color = colorRampPalette(brewer.pal(9, "Spectral"))(50),
         fontsize_row = 8,fontsize_col = 8
)

# Figure 2 j
# Figure 5 h
library(Seurat)
load('TRM-celltype.Rdata')
My_levels <- c('D_38_5','D_45_5','D_37_5','D_48_5','D_40_5','D_47_5')
Idents(object = sce) <- "orig.ident"  # orig.ident  celltype
Idents(sce) <- factor(Idents(sce),ordered=TRUE, levels= My_levels)  #改变顺序
Idents(sce) 
VlnPlot(sce, features = "IL7R",pt.size = 0.5,adjust=1) +
  scale_fill_manual(values = c("#8B8878","#CDC8B1","#EEE8CD","#C1FFC1","#76EE00","#228B22",'blue','yellow'))

# Figure 3 m
library(Seurat)
library(ggplot2)
library(patchwork)
library(dplyr)
library(monocle)
library(ggsci)
load('TRM-celltype.Rdata')
Idents(object = sce) <- "celltype"
levels(Idents(sce))
sce = sce[, Idents(sce) %in% 
            c( "TRMKLRC1", "TRMGZMK", "TRMTCF7"  )] # CD16
sce
levels(Idents(sce))
markers_df <- FindMarkers(object = sce, 
                          ident.1 = 'TRMTCF7',
                          ident.2 = 'TRMGZMK',
                          ident.3 = 'TRMKLRC1',
                          #logfc.threshold = 0,
                          min.pct = 0.25)
head(markers_df)
cg_markers_df=markers_df[abs(markers_df$avg_log2FC) >1,]

dim(cg_markers_df) 
cg_markers_df=cg_markers_df[order(cg_markers_df$avg_log2FC),]
sample_ann <-  sce@meta.data  
sample_ann$celltype=Idents(sce)
gene_ann <- data.frame(
  gene_short_name = rownames(sce@assays$RNA) , 
  row.names =  rownames(sce@assays$RNA) 
)
pd <- new("AnnotatedDataFrame",
          data=sample_ann)
fd <- new("AnnotatedDataFrame",
          data=gene_ann)
ct=as.data.frame(sce@assays$RNA@counts)
sc_cds <- newCellDataSet(
  as.matrix(ct), 
  phenoData = pd,
  featureData =fd,
  expressionFamily = negbinomial.size(),
  lowerDetectionLimit=1)
sc_cds
sc_cds <- detectGenes(sc_cds, min_expr = 1) 
sc_cds <- sc_cds[fData(sc_cds)$num_cells_expressed > 10, ]
cds <- sc_cds
cds <- estimateSizeFactors(cds)
cds <- estimateDispersions(cds) 
disp_table <- dispersionTable(cds)
unsup_clustering_genes <- subset(disp_table,
                                 mean_expression >= 0.1)
unsup_clustering_genes
cds <- setOrderingFilter(cds, 
                         unsup_clustering_genes$gene_id)
plot_ordering_genes(cds) 
plot_pc_variance_explained(cds, 
                           return_all = F)
cds <- reduceDimension(cds, max_components = 2, num_dim = 5,
                       reduction_method = 'tSNE', verbose = T)
cds <- clusterCells(cds, num_clusters = 5) 
plot_cell_clusters(cds, 1, 2 )
pData(cds)$Cluster=pData(cds)$celltype
diff_test_res <- differentialGeneTest(cds,
                                      fullModelFormulaStr = "~Cluster")
ordering_genes <- row.names (subset(diff_test_res, qval < 0.01))
ordering_genes
cds <- setOrderingFilter(cds, ordering_genes)
plot_ordering_genes(cds) 
cds <- reduceDimension(cds, max_components = 2,
                       method = 'DDRTree')
cds2 <- orderCells(cds, root_state = 4)
plot_cell_trajectory(cds2, color_by = "Pseudotime",show_tree = T,show_backbone = T,show_branch_points = F) 
colour=c('#B26054',"#5C8FAE",'#D9AD7F',"#599574")
plot_cell_trajectory(cds2, color_by = "celltype",show_tree = T,show_backbone = T,show_branch_points = F)+ scale_color_manual(values = colour)

# Figure 5 e
# Figure 6 b
# Figure 6 d
#Extended Data Figure 4 b
#Extended Data Figure 4 g
#Extended Data Figure 5 f
#Extended Data Figure 6 i
#Extended Data Figure 8 b
#Extended Data Figure 10 b
library(Seurat)
load('TRM-celltype.Rdata')
genes_to_check = c(
  'GZMK','CD38','ZNF683','KLRC1','GZMB','ENTPD1','IL7R','TCF7','CCR7')
DotPlot(sce, group.by = 'celltype',assay='RNA' , 
        features = unique(genes_to_check)) + RotatedAxis()+ 
  coord_flip()+ scale_colour_gradient2(low = "blue", mid = "pink",high = "red")

# Figure 6 c
# Extended Data Figure 3 b
library(ggplot2)
library(limma)
library(pheatmap)
library(ggsci)
library(dplyr)
rt=read.table("******.txt",sep="\t",header=T,check.names=F)  #Figure 6 c/Extended Data Figure 3 b
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp),colnames(exp))
rt=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
rt=avereps(rt)
data<-na.omit(rt)
head(data)
rt=data
max(rt)
head(rt)
if(max(rt)>30) rt=log2(rt+1)
rt=normalizeBetweenArrays(as.matrix(rt))
data=rt
head(data)
afcon=13 #Modify according to the number of specimens  13/21
conData=data[,as.vector(colnames(data)[1:afcon])]
aftreat=afcon+1
treatData=data[,as.vector(colnames(data)[aftreat:ncol(data)])]
rt=cbind(conData,treatData)
conNum=ncol(conData)
treatNum=ncol(treatData)
Type=c(rep("con",conNum),rep("treat",treatNum))
design <- model.matrix(~0+factor(Type))
colnames(design) <- c("con","treat")
fit <- lmFit(rt,design)
cont.matrix<-makeContrasts(treat-con,levels=design)
fit2 <- contrasts.fit(fit, cont.matrix)
fit2 <- eBayes(fit2)
Diff=topTable(fit2,adjust='fdr',number=length(rownames(data)))
adjP=0.05
aflogFC=1
Significant=ifelse((Diff$P.Value<adjP & abs(Diff$logFC)>aflogFC), ifelse(Diff$logFC>aflogFC,"Up","Down"), "Not")
p = ggplot(Diff, aes(logFC, -log10(P.Value)))+
  geom_point(aes(col=Significant),size=2)+
  scale_color_manual(values=c(pal_npg()(2)[2], "#838B8B", pal_npg()(1)))+
  labs(title = " ")+
  theme(plot.title = element_text(size = 16, hjust = 0.5, face = "bold"))+
  geom_hline(aes(yintercept=-log10(adjP)), colour="gray", linetype="twodash",size=1)+
  geom_vline(aes(xintercept=aflogFC), colour="gray", linetype="twodash",size=1)+
  geom_vline(aes(xintercept=-aflogFC), colour="gray", linetype="twodash",size=1)
p
point.Pvalue=0.05
point.logFc=1
Diff$symbol=rownames(Diff)
p=p+theme_bw()
for_label2 <- Diff %>% 
  filter(abs(logFC) >point.logFc & P.Value< point.Pvalue )
abc=c('CD1C','FCER1A','CD1E','CXCL17','KRT8','KRT18','KRT7','EPCAM','KLRC2','CTLA4','LAG3','GNLY',  #Modified for specific genes
      'KLRC1','GZMB','ZNF683', 'GZMA','CD8A','PDCD1','CXCR6','GLB1L2','SIRPG','SLC16A1','VWA2','CGREF1'
      ,'C11orf52','ABCC3','SCN9A','PDCHAC1','RIMKLA','USP29','LRRC31')
for_label=for_label2[abc,]
p+geom_point(size =1, shape = 2, data = for_label) +
  ggrepel::geom_label_repel(
    aes(label = symbol),
    data = for_label,max.overlaps=20,
    color="black",
    label.size =0.1
  )

# Figure 6 e
# Figure 6 f
library(ggplot2)
rows <- read.csv("******.csv",row.names = 1,check.names = FALSE)  #Figure 6 e f
if(max(rows)>30) rows=log2(rows+1)
cols <- read.csv("******.csv",row.names = 1,check.names = FALSE)  #Figure 6 e/Figure 6 f
if(max(cols)>30) cols=log2(cols+1)
library(psych)
data.corr <- corr.test(rows, cols, method="pearson", adjust="fdr")
data.r <- data.corr$r  
data.p <- data.corr$p  
library(pheatmap)
pheatmap(data.r,clustering_method = "average",cluster_rows=F,cluster_cols=F,
)
getSig <- function(dc) {
  sc <- ''
  if (dc < 0.0001) sc <- '****'
  else if (dc < 0.001) sc <- '***'
  else if (dc < 0.01) sc <- '**'
  else if (dc < 0.05) sc <- '*'
  sc
}
sig.mat <- matrix(sapply(data.p, getSig), nrow=nrow(data.p))
str(sig.mat)
bk <- c(seq(-0.4,-0.1,by=0.01),seq(0,0.4,by=0.01))  
col = c(colorRampPalette(colors = c("purple", "black"))(length(bk)/2),
        colorRampPalette(colors = c( "black", "gold"))(length(bk)/2))
pheatmap(data.r, clustering_method="average", 
         cluster_cols=F, cluster_rows=F,cellwidth=12,cellheight = 10,
         display_numbers=sig.mat,
         fontsize_number = 12, number_color = "white",
         color = colorRampPalette(c("purple", "white", "red"))(100),
         angle_col = 45,
         fontsize_row = 10,fontsize_col = 10
         ,gaps_col = c(9)
)

#Extended Data Figure 2 c
#Extended Data Figure 4 d
#Extended Data Figure 5 d
#Extended Data Figure 5 g
#Extended Data Figure 6 c
#Extended Data Figure 6 j
#Extended Data Figure 7 c
#Extended Data Figure 8 c
#Extended Data Figure 10 c
library(reshape2)
library(ggplot2)
library(tidyr)
library(tibble)
library(dplyr)
x = read.csv("single epi.csv",  #Extended Data Figure 2 c (left)/Extended Data Figure 2 c (middle)/Extended Data Figure 2 c (right)
             header = TRUE, row.names = NULL,check.names=F)
res_per = x%>%
  as.data.frame()%>%
  rownames_to_column() 
aql <- melt(res_per)
table(aql$rowname)
aql$rowname <- factor(aql$rowname,levels=paste0("",1:22),ordered = TRUE)
col=c('#c1d68d','#ffbdfe','#fea568','#33ff33','#4babad','#f4397c','#33b2ff', #Modify according to the number of specimens 
      '#ae7068','#ff33c5','#ff3333','#3333ff', 
      '#33ffcb','#9365ce','#337533','#ffdc33')
rownames(aql)
ggplot(data = aql, mapping = aes(x =value , y = factor(rowname), fill = variable
)) + 
  geom_bar(stat = 'identity', width = 1,position = 'stack')+ 
  scale_fill_manual(values=col)+
  labs(x = "",y = "", title = "")+
  theme(
    legend.title = element_blank(),              
    legend.position = 'right',               
    legend.key.size=unit(0.8,'cm'),
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    axis.line = element_line(size=0),
    axis.text=element_blank(),
    axis.ticks=element_blank(),
    panel.grid = element_blank(),
    panel.border = element_blank())+
  theme_bw()+
  theme_classic()+   
  coord_flip()

#Extended Data Figure 3 a 
rt=read.table("******.txt",sep="\t",header=T,check.names=F)  #Extended Data Figure 3 a-1
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp),colnames(exp))
rt=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
rt=avereps(rt)
data<-na.omit(rt)
head(data)
rt=data
max(rt)
head(rt)
if(max(rt)>30) rt=log2(rt+1)
rt=normalizeBetweenArrays(as.matrix(rt))
inter3=read.table("******.txt",sep="\t",header=T,check.names=F)   #Extended Data Figure 3 a-2 and 3 c
head(inter3)
x1=inter3[,1]
rt3=rt[x1,]
wine=t(rt3)
wine[3,3]
which(apply(wine, 2, var)==0)
wine2=wine[ , which(apply(wine, 2, var) != 0)]
wine.pca <- prcomp(wine2,scale=T)
ggbiplot(wine.pca, obs.scale = 1,var.scale = 1, 
         groups=rep(c('anti-PD-1','T','N'), c(22,21,17)),  #groups=rep(c('Part-PR','Non-PR','T','N'), c(9,13,21,17)),
         var.axes=F, ellipse = TRUE, circle = TRUE) +
  scale_color_discrete(name = '') +
  scale_color_manual(name="Variety",values=c('red','green','blue'))+ # values=c('orange','grey','blue','green')
  theme(legend.position = 'right')

#Extended Data Figure 3 d 
bk <- c(seq(-5,-0.1,by=0.01),seq(0,16,by=0.01))
col = c(colorRampPalette(colors = c("purple", "black"))(length(bk)/2),
        colorRampPalette(colors = c( "black", "gold"))(length(bk)/2))
pheatmap(afExp,                                                                     
         color = col,legend_breaks = seq(-2,1,2),
         breaks=bk,     
         cluster_cols =F,cluster_rows =T,                                                        
         show_colnames = F,      show_rownames = F,                                                  
         fontsize = 10,
         fontsize_row=6,
         fontsize_col=8,
         annotation_colors=anncolor
)

#Extended Data Figure 3 d and e 
NR_PR=read.table("******.txt",sep="\t",header=T,check.names=F) #Extended Data Figure 3 d and e - Non-PR-Part-PR_af
N_PR=read.table("******.txt",sep="\t",header=T,check.names=F) #Extended Data Figure 3 d and e - N-Part-PR_af
T_PR=read.table("******.txt",sep="\t",header=T,check.names=F) #Extended Data Figure 3 d and e - T-Part-PR_af
set1=NR_PR[,1]
set2=N_PR[,1]
set3=T_PR[,1]
library(gplots)
input = list(set1, set2, set3)
library(ggvenn)
library(VennDiagram)
library(RColorBrewer)
ggvenn(input,c("set1","set2","set3"))
color <- brewer.pal(3, "Set3")
venn.diagram(
  x = list(set1, set2, set3),
  category.names = c("Set 1" , "Set 2 " , "Set 3"),
  filename = 'venn2.png',
  output=TRUE,lwd = 5,lty = 1,fill = color,
  col = c("red", 'green', 'blue')
)
xall=c(NR_PR,N_PR,T_PR)
afExp=rt[xall,]
anncolor=list(Type=c(T=pal_npg()(1),N=pal_npg()(2)[2]))
bk <- c(seq(-3,-0.1,by=0.01),seq(0,3,by=0.01))
col = c(colorRampPalette(colors = c("purple", "black"))(length(bk)/2),
        colorRampPalette(colors = c( "black", "gold"))(length(bk)/2))
pheatmap(afExp,                                                        
         color=col,breaks=bk, 
         cluster_cols =F,                                                           
         show_colnames = F,                                                         
         scale="row", 
         fontsize = 10,
         fontsize_row=6,
         fontsize_col=8,treeheight_row=10,
         annotation_colors=anncolor,gaps_col = c(9,22,43)
)

#Extended Data Figure 3 f 
ego_result_BP=read.csv(file = "******.csv",header=T,check.names=F)  #Extended Data Figure 3 f - ego_result_BP
rownames(ego_result_BP)<- ego_result_BP$Description
abcd=c('negative regulation of immune system process','T cell activation',
       'regulation of cell-cell adhesion','regulation of immune effector process','cell chemotaxis',
       'mononuclear cell differentiation','regulation of T cell activation','myeloid leukocyte migration',
       'leukocyte chemotaxis','regulation of leukocyte migration','T cell differentiation')
ego_result_BP <- as.data.frame(ego_result_BP)[abcd, ]
rownames(ego_result_BP) <- 1:nrow(ego_result_BP)
ego_result_BP$order=factor(rev(as.integer(rownames(ego_result_BP))),labels = rev(ego_result_BP$Description))
ggplot(ego_result_BP,aes(y=order,x=Count))+
  geom_point(aes(size=Count,color=-1*p.adjust))+
  scale_color_gradient(low="green",high = "red")+
  labs(color=expression(p.adjust,size="Count"), 
       x="Gene Number",y="Pathways",title="GO-BP Enrichment")+
  theme_bw()
ego_result_MF=read.csv(file = "******.csv",header=T,check.names=F)  #Extended Data Figure 3 f - ego_result_MF
rownames(ego_result_MF)<- ego_result_MF$Description
abcd=c('receptor ligand activity','signaling receptor activator activity','cytokine activity',
       'immune receptor activity', 'chemokine activity',
       'chemokine receptor binding','MHC class I protein binding','MHC class Ib receptor activity')
ego_result_MF <- as.data.frame(ego_result_MF)[abcd, ]
rownames(ego_result_MF) <- 1:nrow(ego_result_MF)
ego_result_MF$order=factor(rev(as.integer(rownames(ego_result_MF))),labels = rev(ego_result_MF$Description))
ggplot(ego_result_MF,aes(y=order,x=Count))+
  geom_point(aes(size=Count,color=-1*p.adjust))+
  scale_color_gradient(low="green",high = "red")+
  labs(color=expression(p.adjust,size="Count"), 
       x="Gene Number",y="Pathways",title="GO-MF Enrichment")+
  theme_bw()

kk=read.csv(file = "******.csv",header=T,check.names=F)   #Extended Data Figure 3 f - kegg
hh <- as.data.frame(kk)
rownames(hh) <- 1:nrow(hh)
hh$order=factor(rev(as.integer(rownames(hh))),labels = rev(hh$Description))
rownames(hh)<- hh$Description
abcd=c('Cytokine-cytokine receptor interaction', 'Chemokine signaling pathway','Cell adhesion molecules',
       'Antigen processing and presentation'
)
hh2 <- as.data.frame(hh)[abcd, ]
rownames(hh2) <- 1:nrow(hh2)
hh2$order=factor(rev(as.integer(rownames(hh2))),labels = rev(hh2$Description))
ggplot(hh2,aes(y=order,x=Count))+
  geom_point(aes(size=Count,color=-1*p.adjust))+
  scale_color_gradient(low="green",high = "red")+
  labs(color=expression(p.adjust,size="Count"), 
       x="Gene Number",y="Pathways",title="GO-BP Enrichment")+
  theme_bw()

#Extended Data Figure 4 e
#Extended Data Figure 4 h
#Extended Data Figure 5 h
#Extended Data Figure 6 i
#Extended Data Figure 8 e
library(reshape2)
library(ggplot2)
library(tidyr)
library(tibble)
library(dplyr)
library(ggpubr)
x = read.csv("******.csv",  #Extended Data Figure 4 d and e/Extended Data Figure 4 h (left)/Extended Data Figure 4 h (right)
             header = TRUE, row.names = NULL,check.names=F)
res_per = x%>%
  as.data.frame()%>%
  rownames_to_column()%>%
  mutate(group= c(
    "PPR","PPR","PPR","NPR","NPR","NPR"))
mydata <- melt(res_per)  
ggboxplot(mydata, x = "variable", y = "value", width = 0.8,
          color = "group",
          add = "jitter", palette = "jama",
          xlab ="",ylab ="")+
  theme(
    axis.text.x = element_blank(),axis.text.y = element_blank(),
    legend.position = 'none'
  )+
  scale_color_manual(values=c("orange","#999999" ))




